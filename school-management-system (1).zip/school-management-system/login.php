<?php
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    redirect(dashboard_path($_SESSION['role']));
}

const MAX_ATTEMPTS = 5;
const LOCK_SECONDS = 300;

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (($_SESSION['lock_until'] ?? 0) > time()) {
        $error = 'Too many failed attempts. Please try again in a few minutes.';
    } elseif (!verify_csrf()) {
        $error = 'Your session expired. Please reload the page and try again.';
    } elseif ($username === '' || $password === '') {
        $error = 'Please enter both username and password.';
    } elseif (strlen($username) > 50) {
        $error = 'Invalid username or password.';
    } else {
        $db = getDB();
        $stmt = $db->prepare('SELECT id, username, password_hash, role, status FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $u = $stmt->fetch();

        if ($u && $u['status'] === 'active' && password_verify($password, $u['password_hash'])) {
            session_regenerate_id(true);
            unset($_SESSION['login_attempts'], $_SESSION['lock_until']);
            $_SESSION['user_id']      = (int)$u['id'];
            $_SESSION['username']     = $u['username'];
            $_SESSION['role']         = $u['role'];
            $_SESSION['display_name'] = lookup_display_name($db, (int)$u['id'], $u['role'], $u['username']);
            $db->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$u['id']]);
            redirect(dashboard_path($u['role']));
        }

        $_SESSION['login_attempts'] = ($_SESSION['login_attempts'] ?? 0) + 1;
        if ($_SESSION['login_attempts'] >= MAX_ATTEMPTS) {
            $_SESSION['lock_until'] = time() + LOCK_SECONDS;
            $_SESSION['login_attempts'] = 0;
        }
        $error = 'Invalid username or password.';
    }
}
$flashes = get_flashes();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login | <?= e(APP_NAME) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="login-page">
  <div class="login-card">
    <div class="login-side">
      <div class="brand-icon"><i class="bi bi-mortarboard-fill"></i></div>
      <h2 class="fw-bold"><?= e(APP_NAME) ?></h2>
      <p class="opacity-75 mb-4">One place for students, teachers, parents and administrators.</p>
      <ul class="list-unstyled opacity-90 mb-0">
        <li class="mb-2"><i class="bi bi-check2-circle me-2"></i>Attendance &amp; examination results</li>
        <li class="mb-2"><i class="bi bi-check2-circle me-2"></i>Fee tracking &amp; receipts</li>
        <li class="mb-2"><i class="bi bi-check2-circle me-2"></i>Timetables &amp; notice board</li>
      </ul>
    </div>
    <div class="login-form">
      <h3 class="fw-bold mb-1">Welcome back</h3>
      <p class="text-muted mb-4">Sign in to your account</p>

      <?php foreach ($flashes as $f): ?>
        <div class="alert alert-<?= e($f['type']) ?>"><?= e($f['message']) ?></div>
      <?php endforeach; ?>
      <?php if ($error): ?>
        <div class="alert alert-danger"><i class="bi bi-exclamation-circle me-1"></i><?= e($error) ?></div>
      <?php endif; ?>

      <form method="post" action="" novalidate>
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label fw-medium" for="username">Username</label>
          <input type="text" class="form-control" id="username" name="username" maxlength="50"
                 value="<?= e($username) ?>" autocomplete="username" required autofocus>
        </div>
        <div class="mb-4">
          <label class="form-label fw-medium" for="password">Password</label>
          <div class="input-group">
            <input type="password" class="form-control" id="password" name="password" autocomplete="current-password" required>
            <button class="btn btn-outline-secondary" type="button" data-toggle-password="#password" aria-label="Show password"><i class="bi bi-eye"></i></button>
          </div>
        </div>
        <button class="btn btn-primary w-100 py-2 fw-semibold" type="submit">Sign in</button>
      </form>

      <div class="demo-box">
        <div class="fw-semibold mb-1">Demo accounts</div>
        <div>Admin: <code>admin</code> / <code>Admin@123</code></div>
        <div>Teacher: <code>teacher1</code> / <code>Teacher@123</code></div>
        <div>Student: <code>student1</code> / <code>Student@123</code></div>
        <div>Parent: <code>parent1</code> / <code>Parent@123</code></div>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>
</html>
