<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['student']);
$db = getDB();

$stmt = $db->prepare(
    'SELECT s.*, c.name AS class_name, sec.name AS section_name
     FROM students s JOIN classes c ON c.id = s.class_id LEFT JOIN sections sec ON sec.id = s.section_id
     WHERE s.user_id = ?'
);
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();
if (!$student) {
    flash('danger', 'Student profile not found. Contact the administrator.');
    redirect('logout.php');
}

$att    = attendance_summary($db, (int)$student['id']);
$fees   = fee_summary($db, (int)$student['id']);
$result = latest_result($db, (int)$student['id']);
$notices = notices_for($db, 'student', 5);

$today = date('l');
$stmt = $db->prepare(
    'SELECT t.period_no, t.start_time, t.end_time, s.name AS subject_name, te.name AS teacher_name
     FROM timetable t JOIN subjects s ON s.id = t.subject_id LEFT JOIN teachers te ON te.id = t.teacher_id
     WHERE t.class_id = ? AND t.day_of_week = ? ORDER BY t.period_no'
);
$stmt->execute([$student['class_id'], $today]);
$periods = $stmt->fetchAll();

$pageTitle = 'Student Dashboard';
include __DIR__ . '/../includes/header.php';
?>
<div class="card mb-3">
  <div class="card-body d-flex flex-wrap align-items-center gap-3">
    <span class="avatar" style="width:60px;height:60px;font-size:1.5rem"><?= e(strtoupper(substr($student['name'], 0, 1))) ?></span>
    <div>
      <h5 class="mb-0"><?= e($student['name']) ?></h5>
      <div class="text-muted"><?= e($student['class_name']) ?><?= $student['section_name'] ? ' - Section ' . e($student['section_name']) : '' ?>
        &middot; Admission No. <?= e($student['admission_no']) ?></div>
    </div>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-md-4"><div class="card stat-card"><div class="stat-icon blue"><i class="bi bi-calendar-check"></i></div>
    <div class="flex-grow-1"><div class="stat-value"><?= $att['percent'] ?>%</div><div class="stat-label mb-1">Attendance (<?= $att['present'] + $att['late'] ?>/<?= $att['total'] ?> days)</div>
      <div class="progress"><div class="progress-bar" style="width:<?= $att['percent'] ?>%"></div></div></div></div></div>
  <div class="col-md-4"><div class="card stat-card"><div class="stat-icon green"><i class="bi bi-journal-text"></i></div>
    <div><?php if ($result): ?>
      <div class="stat-value"><?= $result['percent'] ?>% <span class="badge-soft green fs-6"><?= e($result['grade']) ?></span></div>
      <div class="stat-label">Latest: <?= e($result['name']) ?></div>
      <?php else: ?><div class="stat-value">-</div><div class="stat-label">No results published yet</div><?php endif; ?></div></div></div>
  <div class="col-md-4"><div class="card stat-card"><div class="stat-icon <?= $fees['pending'] > 0 ? 'red' : 'green' ?>"><i class="bi bi-cash-coin"></i></div>
    <div><div class="stat-value"><?= e(money($fees['pending'])) ?></div><div class="stat-label">Fees pending (paid <?= e(money($fees['paid'])) ?>)</div></div></div></div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header">Today's timetable &middot; <?= e($today) ?></div>
      <div class="card-body">
        <?php if (!$periods): ?><div class="empty-state">No classes scheduled today.</div><?php endif; ?>
        <?php foreach ($periods as $p): ?>
          <div class="d-flex justify-content-between align-items-center notice-item">
            <div><strong><?= e($p['subject_name']) ?></strong><div class="text-muted small"><?= e($p['teacher_name'] ?? 'Teacher TBA') ?> &middot; Period <?= (int)$p['period_no'] ?></div></div>
            <span class="badge-soft blue"><?= e(date('h:i A', strtotime($p['start_time']))) ?> - <?= e(date('h:i A', strtotime($p['end_time']))) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card">
      <div class="card-header">Notices</div>
      <div class="card-body">
        <?php if (!$notices): ?><div class="empty-state">No notices.</div><?php endif; ?>
        <?php foreach ($notices as $n): ?>
          <div class="notice-item">
            <strong><?= e($n['title']) ?></strong>
            <p class="mb-1 text-muted small"><?= e($n['body']) ?></p>
            <small class="text-muted"><?= e(date('d M Y', strtotime($n['notice_date']))) ?></small>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
