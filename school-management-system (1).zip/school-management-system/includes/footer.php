    </main>
    <footer class="app-footer">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?> &middot; School Management System</footer>
  </div><!-- /.app-main -->
</div><!-- /.app-shell -->

<!-- Delete confirmation modal (used by any element with data-confirm) -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-body text-center p-4">
        <div class="confirm-icon"><i class="bi bi-exclamation-triangle"></i></div>
        <h5 class="mt-3">Are you sure?</h5>
        <p class="text-muted mb-4" id="confirmMessage">This action cannot be undone.</p>
        <button type="button" class="btn btn-light me-2" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmOk">Yes, continue</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
<?= $pageScripts ?? '' ?>
</body>
</html>
