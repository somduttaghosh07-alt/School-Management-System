<?php
/**
 * Sidebar menus per role: [label, bootstrap-icon, path relative to project root].
 * Links whose target file does not exist yet are hidden automatically
 * (see sidebar.php), so the menu never shows a dead link.
 */
function menu_for(string $role): array
{
    $menus = [
        'admin' => [
            ['Dashboard',  'speedometer2',   'admin/dashboard.php'],
            ['Students',   'mortarboard',    'admin/students.php'],
            ['Teachers',   'person-workspace','admin/teachers.php'],
            ['Parents',    'people',         'admin/parents.php'],
            ['Classes & Subjects', 'building', 'admin/classes.php'],
            ['Attendance', 'calendar-check', 'admin/attendance.php'],
            ['Examinations','journal-text',  'admin/exams.php'],
            ['Fees',       'cash-coin',      'admin/fees.php'],
            ['Timetable',  'clock-history',  'admin/timetable.php'],
            ['Notices',    'megaphone',      'admin/notices.php'],
            ['Reports',    'bar-chart-line', 'admin/reports.php'],
        ],
        'teacher' => [
            ['Dashboard',  'speedometer2',   'teacher/dashboard.php'],
            ['My Classes', 'building',       'teacher/classes.php'],
            ['Students',   'mortarboard',    'teacher/students.php'],
            ['Attendance', 'calendar-check', 'teacher/attendance.php'],
            ['Enter Marks','journal-text',   'teacher/marks.php'],
            ['Timetable',  'clock-history',  'teacher/timetable.php'],
            ['Notices',    'megaphone',      'teacher/notices.php'],
        ],
        'student' => [
            ['Dashboard',  'speedometer2',   'student/dashboard.php'],
            ['My Profile', 'person-circle',  'student/profile.php'],
            ['Attendance', 'calendar-check', 'student/attendance.php'],
            ['Results',    'journal-text',   'student/results.php'],
            ['Fees',       'cash-coin',      'student/fees.php'],
            ['Timetable',  'clock-history',  'student/timetable.php'],
            ['Notices',    'megaphone',      'student/notices.php'],
        ],
        'parent' => [
            ['Dashboard',  'speedometer2',   'parent/dashboard.php'],
            ['My Children','people',         'parent/children.php'],
            ['Attendance', 'calendar-check', 'parent/attendance.php'],
            ['Results',    'journal-text',   'parent/results.php'],
            ['Fees',       'cash-coin',      'parent/fees.php'],
            ['Notices',    'megaphone',      'parent/notices.php'],
        ],
    ];
    $root = dirname(__DIR__) . '/';
    return array_values(array_filter($menus[$role] ?? [], fn($m) => file_exists($root . $m[2])));
}
