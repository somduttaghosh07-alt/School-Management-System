<?php
/**
 * Session handling, CSRF protection, role-based authorization and helpers.
 * Include this file at the top of every page.
 */
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/* ---------- Output escaping ---------- */
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/* ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): bool
{
    $sent = $_POST['csrf_token'] ?? '';
    return is_string($sent) && hash_equals($_SESSION['csrf_token'] ?? '', $sent);
}

/* ---------- Flash messages ---------- */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

/* ---------- Navigation ---------- */
function redirect(string $path): void
{
    header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
    exit;
}

function dashboard_path(string $role): string
{
    return [
        'admin'   => 'admin/dashboard.php',
        'teacher' => 'teacher/dashboard.php',
        'student' => 'student/dashboard.php',
        'parent'  => 'parent/dashboard.php',
    ][$role] ?? 'login.php';
}

/* ---------- Authentication / authorization ---------- */
function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

function current_user(): array
{
    return [
        'id'       => $_SESSION['user_id'] ?? null,
        'username' => $_SESSION['username'] ?? '',
        'role'     => $_SESSION['role'] ?? '',
        'name'     => $_SESSION['display_name'] ?? '',
    ];
}

function require_login(): void
{
    if (!is_logged_in()) {
        flash('warning', 'Please log in to continue.');
        redirect('login.php');
    }
}

/** Allow only the listed roles; everyone else is sent back to their own dashboard. */
function require_role(array $roles): void
{
    require_login();
    if (!in_array($_SESSION['role'], $roles, true)) {
        flash('danger', 'You are not authorized to view that page.');
        redirect(dashboard_path($_SESSION['role']));
    }
}

/** Human readable name for the logged-in user, looked up from the role table. */
function lookup_display_name(PDO $db, int $userId, string $role, string $fallback): string
{
    $table = ['teacher' => 'teachers', 'student' => 'students', 'parent' => 'parents'][$role] ?? null;
    if ($table === null) {
        return 'Administrator';
    }
    $stmt = $db->prepare("SELECT name FROM $table WHERE user_id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetchColumn() ?: $fallback;
}

function log_activity(string $action): void
{
    try {
        getDB()->prepare('INSERT INTO activity_log (user_id, action) VALUES (?, ?)')
               ->execute([$_SESSION['user_id'] ?? null, $action]);
    } catch (PDOException $ex) {
        // logging must never break a page
    }
}

/* ---------- Business helpers shared by dashboards ---------- */
function grade_for(float $percent): string
{
    if ($percent >= 90) return 'A+';
    if ($percent >= 80) return 'A';
    if ($percent >= 70) return 'B+';
    if ($percent >= 60) return 'B';
    if ($percent >= 50) return 'C';
    if ($percent >= 40) return 'D';
    return 'F';
}

/** Attendance counts; "late" still counts as attended for the percentage. */
function attendance_summary(PDO $db, int $studentId): array
{
    $stmt = $db->prepare(
        "SELECT COALESCE(SUM(status='present'),0) AS present,
                COALESCE(SUM(status='absent'),0)  AS absent,
                COALESCE(SUM(status='late'),0)    AS late,
                COUNT(*) AS total
         FROM attendance WHERE student_id = ?"
    );
    $stmt->execute([$studentId]);
    $r = array_map('intval', $stmt->fetch());
    $r['percent'] = $r['total'] > 0 ? round((($r['present'] + $r['late']) / $r['total']) * 100, 1) : 0.0;
    return $r;
}

function fee_summary(PDO $db, int $studentId): array
{
    $stmt = $db->prepare(
        "SELECT COALESCE((SELECT SUM(fs.amount) FROM fee_structures fs WHERE fs.class_id = s.class_id),0) AS total,
                COALESCE((SELECT SUM(fp.amount_paid) FROM fee_payments fp WHERE fp.student_id = s.id),0)   AS paid
         FROM students s WHERE s.id = ?"
    );
    $stmt->execute([$studentId]);
    $r = $stmt->fetch() ?: ['total' => 0, 'paid' => 0];
    $total = (float)$r['total'];
    $paid  = (float)$r['paid'];
    return ['total' => $total, 'paid' => $paid, 'pending' => max(0, $total - $paid)];
}

/** Most recent exam with entered marks for the student. */
function latest_result(PDO $db, int $studentId): ?array
{
    $stmt = $db->prepare(
        "SELECT e.name, e.id AS exam_id,
                SUM(m.marks_obtained) AS obtained, SUM(es.max_marks) AS maximum
         FROM marks m
         JOIN examinations e ON e.id = m.exam_id
         JOIN exam_subjects es ON es.exam_id = m.exam_id AND es.subject_id = m.subject_id
         WHERE m.student_id = ?
         GROUP BY e.id, e.name, e.end_date
         ORDER BY e.end_date DESC LIMIT 1"
    );
    $stmt->execute([$studentId]);
    $r = $stmt->fetch();
    if (!$r) return null;
    $r['percent'] = $r['maximum'] > 0 ? round($r['obtained'] / $r['maximum'] * 100, 1) : 0;
    $r['grade']   = grade_for((float)$r['percent']);
    return $r;
}

function notices_for(PDO $db, string $role, int $limit = 5): array
{
    $audience = ['teacher' => 'teachers', 'student' => 'students', 'parent' => 'parents'][$role] ?? null;
    if ($audience === null) { // admin sees everything
        $stmt = $db->prepare('SELECT * FROM notices ORDER BY notice_date DESC, id DESC LIMIT ' . (int)$limit);
        $stmt->execute();
    } else {
        $stmt = $db->prepare("SELECT * FROM notices WHERE audience IN ('all', ?) ORDER BY notice_date DESC, id DESC LIMIT " . (int)$limit);
        $stmt->execute([$audience]);
    }
    return $stmt->fetchAll();
}

function money($amount): string
{
    return '₹' . number_format((float)$amount, 2);
}
