<?php
/**
 * Shared page shell (head + sidebar + top bar).
 * Before including set: $pageTitle (string). Optional: $pageHead (extra HTML for <head>).
 */
require_once __DIR__ . '/auth.php';
require_login();
require_once __DIR__ . '/menu.php';

$user    = current_user();
$current = basename($_SERVER['PHP_SELF']);
$roleDir = $user['role'];
$initial = strtoupper(substr($user['name'] ?: $user['username'], 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle ?? 'Dashboard') ?> | <?= e(APP_NAME) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">
  <?= $pageHead ?? '' ?>
</head>
<body>
<div class="app-shell">
  <?php include __DIR__ . '/sidebar.php'; ?>
  <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

  <div class="app-main">
    <header class="topbar">
      <button class="btn btn-icon d-lg-none" id="sidebarToggle" aria-label="Toggle menu"><i class="bi bi-list fs-4"></i></button>
      <div class="topbar-title"><?= e($pageTitle ?? 'Dashboard') ?></div>
      <div class="ms-auto dropdown">
        <a href="#" class="user-chip dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
          <span class="avatar"><?= e($initial) ?></span>
          <span class="d-none d-sm-block text-start">
            <span class="d-block fw-semibold lh-sm"><?= e($user['name'] ?: $user['username']) ?></span>
            <small class="text-muted text-capitalize"><?= e($user['role']) ?></small>
          </span>
        </a>
        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
          <li><a class="dropdown-item" href="<?= BASE_URL ?>/change_password.php"><i class="bi bi-key me-2"></i>Change password</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
        </ul>
      </div>
    </header>

    <main class="content">
      <?php foreach (get_flashes() as $f): ?>
        <div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show auto-dismiss" role="alert">
          <?= e($f['message']) ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endforeach; ?>
