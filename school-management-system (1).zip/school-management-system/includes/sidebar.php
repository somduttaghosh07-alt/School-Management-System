<?php
/** Sidebar navigation. Expects $user and $current from header.php. */
?>
<aside class="sidebar" id="sidebar">
  <a class="brand" href="<?= BASE_URL ?>/<?= e(dashboard_path($user['role'])) ?>">
    <span class="brand-icon"><i class="bi bi-mortarboard-fill"></i></span>
    <span><?= e(APP_NAME) ?></span>
  </a>
  <nav class="nav flex-column">
    <?php foreach (menu_for($user['role']) as [$label, $icon, $path]): ?>
      <a class="nav-link <?= basename($path) === $current && str_starts_with($path, $user['role'] . '/') ? 'active' : '' ?>"
         href="<?= BASE_URL ?>/<?= e($path) ?>">
        <i class="bi bi-<?= e($icon) ?>"></i><span><?= e($label) ?></span>
      </a>
    <?php endforeach; ?>
  </nav>
  <div class="sidebar-footer">
    <a class="nav-link" href="<?= BASE_URL ?>/change_password.php"><i class="bi bi-key"></i><span>Change Password</span></a>
    <a class="nav-link" href="<?= BASE_URL ?>/logout.php"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
  </div>
</aside>
