<?php
/**
 * PDO database connection (singleton).
 * Default XAMPP credentials: user "root" with an empty password.
 */
require_once __DIR__ . '/config.php';

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'school_management_system');
define('DB_USER', 'root');
define('DB_PASS', '');

function getDB(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $ex) {
            http_response_code(500);
            exit('<h3 style="font-family:sans-serif">Database connection failed.</h3>'
               . '<p style="font-family:sans-serif">Start MySQL in the XAMPP Control Panel and import '
               . '<code>database/school_management_system.sql</code> using phpMyAdmin.</p>');
        }
    }
    return $pdo;
}
