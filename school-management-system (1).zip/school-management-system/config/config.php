<?php
/**
 * Global application settings.
 * BASE_URL must match the folder name inside C:\xampp\htdocs\
 */
define('APP_NAME', 'Greenfield Public School');
define('BASE_URL', '/school-management-system');
define('UPLOAD_DIR', dirname(__DIR__) . '/uploads/');
define('UPLOAD_URL', BASE_URL . '/uploads/');
define('MAX_UPLOAD_BYTES', 2 * 1024 * 1024); // 2 MB

date_default_timezone_set('Asia/Kolkata');
