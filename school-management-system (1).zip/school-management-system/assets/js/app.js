/* Shared front-end behaviour (vanilla JavaScript) */
document.addEventListener('DOMContentLoaded', function () {

  // ----- mobile sidebar toggle -----
  var sidebar = document.getElementById('sidebar');
  var backdrop = document.getElementById('sidebarBackdrop');
  var toggle = document.getElementById('sidebarToggle');
  function setSidebar(open) {
    if (!sidebar) return;
    sidebar.classList.toggle('open', open);
    if (backdrop) backdrop.classList.toggle('show', open);
  }
  if (toggle) toggle.addEventListener('click', function () { setSidebar(!sidebar.classList.contains('open')); });
  if (backdrop) backdrop.addEventListener('click', function () { setSidebar(false); });

  // ----- auto-dismiss success/info alerts after 5 seconds -----
  document.querySelectorAll('.alert.auto-dismiss.alert-success, .alert.auto-dismiss.alert-info').forEach(function (el) {
    setTimeout(function () {
      if (window.bootstrap) bootstrap.Alert.getOrCreateInstance(el).close();
    }, 5000);
  });

  // ----- confirmation dialog for destructive actions -----
  // Usage: <a href="..." data-confirm="Delete this student?"> or <form data-confirm="...">
  var modalEl = document.getElementById('confirmModal');
  if (modalEl && window.bootstrap) {
    var modal = new bootstrap.Modal(modalEl);
    var pending = null;
    document.addEventListener('click', function (ev) {
      var t = ev.target.closest('a[data-confirm], button[data-confirm]');
      if (!t) return;
      ev.preventDefault();
      document.getElementById('confirmMessage').textContent = t.getAttribute('data-confirm');
      pending = function () {
        if (t.tagName === 'A') { window.location.href = t.href; }
        else if (t.form) { t.form.submit(); }
      };
      modal.show();
    });
    document.getElementById('confirmOk').addEventListener('click', function () {
      modal.hide();
      if (pending) pending();
    });
  }

  // ----- live table filter -----
  // Usage: <input data-table-filter="#myTable" placeholder="Search...">
  document.querySelectorAll('[data-table-filter]').forEach(function (input) {
    input.addEventListener('input', function () {
      var q = input.value.toLowerCase();
      document.querySelectorAll(input.getAttribute('data-table-filter') + ' tbody tr').forEach(function (row) {
        row.style.display = row.textContent.toLowerCase().indexOf(q) > -1 ? '' : 'none';
      });
    });
  });

  // ----- show/hide password -----
  document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.querySelector(btn.getAttribute('data-toggle-password'));
      if (!input) return;
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.innerHTML = show ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
    });
  });
});
