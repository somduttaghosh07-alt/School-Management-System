<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);
$db = getDB();

$count = fn(string $table) => (int)$db->query("SELECT COUNT(*) FROM $table")->fetchColumn();
$totalStudents = $count('students');
$totalTeachers = $count('teachers');
$totalClasses  = $count('classes');
$totalSubjects = $count('subjects');

$collected = (float)$db->query('SELECT COALESCE(SUM(amount_paid),0) FROM fee_payments')->fetchColumn();
$expected  = (float)$db->query(
    'SELECT COALESCE(SUM(t.total),0) FROM students s
     JOIN (SELECT class_id, SUM(amount) total FROM fee_structures GROUP BY class_id) t ON t.class_id = s.class_id'
)->fetchColumn();
$pending = max(0, $expected - $collected);

// Attendance statistics (overall + last 7 recorded days)
$att = $db->query(
    "SELECT COALESCE(SUM(status='present'),0) p, COALESCE(SUM(status='absent'),0) a, COALESCE(SUM(status='late'),0) l, COUNT(*) t FROM attendance"
)->fetch();
$attPercent = $att['t'] > 0 ? round((($att['p'] + $att['l']) / $att['t']) * 100, 1) : 0;

$trend = $db->query(
    "SELECT att_date, ROUND(100*SUM(status<>'absent')/COUNT(*),1) AS pct
     FROM attendance GROUP BY att_date ORDER BY att_date DESC LIMIT 7"
)->fetchAll();
$trend = array_reverse($trend);

$strength = $db->query(
    'SELECT c.name, COUNT(s.id) AS total FROM classes c LEFT JOIN students s ON s.class_id = c.id GROUP BY c.id, c.name ORDER BY c.id'
)->fetchAll();

$activities = $db->query(
    'SELECT a.action, a.created_at, u.username FROM activity_log a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC, a.id DESC LIMIT 6'
)->fetchAll();
$notices = notices_for($db, 'admin', 4);

$pageTitle = 'Admin Dashboard';
include __DIR__ . '/../includes/header.php';

$cards = [
    ['Total Students', $totalStudents, 'mortarboard', 'blue'],
    ['Total Teachers', $totalTeachers, 'person-workspace', 'violet'],
    ['Total Classes',  $totalClasses,  'building', 'amber'],
    ['Total Subjects', $totalSubjects, 'book', 'green'],
    ['Fees Collected', money($collected), 'cash-coin', 'green'],
    ['Pending Fees',   money($pending),   'hourglass-split', 'red'],
    ['Attendance Rate', $attPercent . '%', 'calendar-check', 'blue'],
];
?>
<div class="row g-3 mb-3">
  <?php foreach ($cards as [$label, $value, $icon, $color]): ?>
    <div class="col-6 col-md-4 col-xl-3">
      <div class="card stat-card">
        <div class="stat-icon <?= $color ?>"><i class="bi bi-<?= $icon ?>"></i></div>
        <div><div class="stat-value"><?= e($value) ?></div><div class="stat-label"><?= e($label) ?></div></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-7">
    <div class="card h-100">
      <div class="card-header">Daily attendance (last 7 recorded days)</div>
      <div class="card-body"><div class="chart-box"><canvas id="attTrend"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card h-100">
      <div class="card-header">Fee collection</div>
      <div class="card-body"><div class="chart-box"><canvas id="feeChart"></canvas></div></div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-header">Students per class</div>
      <div class="card-body"><div class="chart-box"><canvas id="classChart"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-header">Recent activities</div>
      <div class="card-body">
        <?php if (!$activities): ?><div class="empty-state">No activity yet.</div><?php endif; ?>
        <?php foreach ($activities as $a): ?>
          <div class="d-flex gap-3 notice-item">
            <span class="activity-dot"></span>
            <div>
              <div><?= e($a['action']) ?></div>
              <small class="text-muted"><?= e($a['username'] ?? 'system') ?> &middot; <?= e(date('d M Y, h:i A', strtotime($a['created_at']))) ?></small>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-header">Latest notices</div>
      <div class="card-body">
        <?php if (!$notices): ?><div class="empty-state">No notices published.</div><?php endif; ?>
        <?php foreach ($notices as $n): ?>
          <div class="notice-item">
            <div class="d-flex justify-content-between align-items-start gap-2">
              <strong><?= e($n['title']) ?></strong>
              <span class="badge-soft blue text-capitalize"><?= e($n['audience']) ?></span>
            </div>
            <small class="text-muted"><?= e(date('d M Y', strtotime($n['notice_date']))) ?></small>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<?php
$pageScripts = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script><script>
const trend = ' . json_encode($trend, JSON_HEX_TAG) . ';
const strength = ' . json_encode($strength, JSON_HEX_TAG) . ';
const fees = ' . json_encode([$collected, $pending]) . ';
const att = ' . json_encode([(int)$att['p'], (int)$att["a"], (int)$att['l']]) . ';
Chart.defaults.font.family = "Inter, sans-serif";
new Chart(document.getElementById("attTrend"), {
  type: "line",
  data: { labels: trend.map(r => r.att_date.slice(5)), datasets: [{ label: "Attendance %", data: trend.map(r => r.pct),
    borderColor: "#2563eb", backgroundColor: "rgba(37,99,235,.12)", fill: true, tension: .35, pointRadius: 4 }] },
  options: { maintainAspectRatio: false, scales: { y: { min: 0, max: 100 } }, plugins: { legend: { display: false } } }
});
new Chart(document.getElementById("feeChart"), {
  type: "doughnut",
  data: { labels: ["Collected", "Pending"], datasets: [{ data: fees, backgroundColor: ["#2563eb", "#cbd5e1"], borderWidth: 0 }] },
  options: { maintainAspectRatio: false, cutout: "68%", plugins: { legend: { position: "bottom" } } }
});
new Chart(document.getElementById("classChart"), {
  type: "bar",
  data: { labels: strength.map(r => r.name), datasets: [{ label: "Students", data: strength.map(r => r.total), backgroundColor: "#3b82f6", borderRadius: 6 }] },
  options: { maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } }
});
</script>';
include __DIR__ . '/../includes/footer.php';
