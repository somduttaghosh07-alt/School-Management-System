# School Management System (Part 1 of N)

PHP + MySQL + HTML/CSS/JavaScript (Bootstrap 5) project for XAMPP.

## What is in Part 1
- Full database (`database/school_management_system.sql`): 17 tables, foreign keys, indexes, and sample data
  (24 students, 6 teachers, 5 classes with sections, 7 subjects, attendance, 2 exams per class with marks, fees, timetable, notices).
- Authentication: login (with lockout after 5 failed tries), logout, change password, bcrypt hashing, CSRF tokens, role-based redirects.
- Shared layout: sidebar, top bar, flash messages, delete-confirmation modal.
- Four role dashboards (admin with charts, teacher, student, parent).

Sidebar links to modules not yet built are hidden automatically; they appear as soon as their files exist.

## Install on XAMPP (Windows)
1. Install XAMPP and start **Apache** and **MySQL** in the Control Panel.
2. Copy the `school-management-system` folder into `C:\xampp\htdocs\`.
3. Open http://localhost/phpmyadmin → **Import** → choose `database/school_management_system.sql` → **Go**.
   (The file creates the `school_management_system` database itself.)
4. Open http://localhost/school-management-system/
5. If you rename the folder, change `BASE_URL` in `config/config.php`. If your MySQL root has a password, set it in `config/database.php`.

The pages load Bootstrap, Chart.js and fonts from a CDN, so the browser needs internet access.

## Demo logins
| Role    | Username   | Password     |
|---------|------------|--------------|
| Admin   | admin      | Admin@123    |
| Teacher | teacher1…6 | Teacher@123  |
| Student | student1…24| Student@123  |
| Parent  | parent1…18 | Parent@123   |

## Folder structure
```
config/      config.php, database.php (PDO)
includes/    auth.php, menu.php, header.php, sidebar.php, footer.php
assets/      css/style.css, js/app.js
admin/ teacher/ student/ parent/   role dashboards (module pages come in later parts)
uploads/     profile photos (PHP execution blocked by .htaccess)
database/    school_management_system.sql
login.php  logout.php  change_password.php  index.php
```
