<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['teacher']);
$db = getDB();

$stmt = $db->prepare('SELECT * FROM teachers WHERE user_id = ?');
$stmt->execute([$_SESSION['user_id']]);
$teacher = $stmt->fetch();
if (!$teacher) {
    flash('danger', 'Teacher profile not found. Contact the administrator.');
    redirect('logout.php');
}

$stmt = $db->prepare(
    'SELECT c.name AS class_name, s.name AS subject_name, s.code,
            (SELECT COUNT(*) FROM students st WHERE st.class_id = c.id) AS students
     FROM teacher_assignments ta
     JOIN classes c ON c.id = ta.class_id
     JOIN subjects s ON s.id = ta.subject_id
     WHERE ta.teacher_id = ? ORDER BY c.id, s.name'
);
$stmt->execute([$teacher['id']]);
$assignments = $stmt->fetchAll();

$today = date('l');
$stmt = $db->prepare(
    'SELECT t.period_no, t.start_time, t.end_time, c.name AS class_name, s.name AS subject_name
     FROM timetable t JOIN classes c ON c.id = t.class_id JOIN subjects s ON s.id = t.subject_id
     WHERE t.teacher_id = ? AND t.day_of_week = ? ORDER BY t.period_no'
);
$stmt->execute([$teacher['id'], $today]);
$periods = $stmt->fetchAll();

$classCount   = count(array_unique(array_column($assignments, 'class_name')));
// distinct students across the teacher's classes
$stmt = $db->prepare(
    'SELECT COUNT(DISTINCT st.id) FROM students st
     WHERE st.class_id IN (SELECT class_id FROM teacher_assignments WHERE teacher_id = ?)'
);
$stmt->execute([$teacher['id']]);
$studentTotal = (int)$stmt->fetchColumn();
$notices = notices_for($db, 'teacher', 5);

$pageTitle = 'Teacher Dashboard';
include __DIR__ . '/../includes/header.php';
?>
<div class="row g-3 mb-3">
  <div class="col-6 col-lg-3"><div class="card stat-card"><div class="stat-icon blue"><i class="bi bi-building"></i></div>
    <div><div class="stat-value"><?= $classCount ?></div><div class="stat-label">Classes assigned</div></div></div></div>
  <div class="col-6 col-lg-3"><div class="card stat-card"><div class="stat-icon violet"><i class="bi bi-book"></i></div>
    <div><div class="stat-value"><?= count($assignments) ?></div><div class="stat-label">Class-subject assignments</div></div></div></div>
  <div class="col-6 col-lg-3"><div class="card stat-card"><div class="stat-icon green"><i class="bi bi-mortarboard"></i></div>
    <div><div class="stat-value"><?= $studentTotal ?></div><div class="stat-label">Students taught</div></div></div></div>
  <div class="col-6 col-lg-3"><div class="card stat-card"><div class="stat-icon amber"><i class="bi bi-clock"></i></div>
    <div><div class="stat-value"><?= count($periods) ?></div><div class="stat-label">Periods today (<?= e($today) ?>)</div></div></div></div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card mb-3">
      <div class="card-header">My classes and subjects</div>
      <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
          <thead><tr><th>Class</th><th>Subject</th><th>Code</th><th class="text-end">Students</th></tr></thead>
          <tbody>
          <?php foreach ($assignments as $a): ?>
            <tr><td><?= e($a['class_name']) ?></td><td><?= e($a['subject_name']) ?></td>
                <td><span class="badge-soft blue"><?= e($a['code']) ?></span></td><td class="text-end"><?= (int)$a['students'] ?></td></tr>
          <?php endforeach; ?>
          <?php if (!$assignments): ?><tr><td colspan="4" class="empty-state">No classes assigned yet.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    <div class="card">
      <div class="card-header">Today's schedule &middot; <?= e($today) ?></div>
      <div class="card-body">
        <?php if (!$periods): ?><div class="empty-state">No periods scheduled today.</div><?php endif; ?>
        <?php foreach ($periods as $p): ?>
          <div class="d-flex justify-content-between align-items-center notice-item">
            <div><strong><?= e($p['subject_name']) ?></strong><div class="text-muted small"><?= e($p['class_name']) ?> &middot; Period <?= (int)$p['period_no'] ?></div></div>
            <span class="badge-soft blue"><?= e(date('h:i A', strtotime($p['start_time']))) ?> - <?= e(date('h:i A', strtotime($p['end_time']))) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card">
      <div class="card-header">Notices</div>
      <div class="card-body">
        <?php if (!$notices): ?><div class="empty-state">No notices.</div><?php endif; ?>
        <?php foreach ($notices as $n): ?>
          <div class="notice-item">
            <strong><?= e($n['title']) ?></strong>
            <p class="mb-1 text-muted small"><?= e($n['body']) ?></p>
            <small class="text-muted"><?= e(date('d M Y', strtotime($n['notice_date']))) ?></small>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
