<?php
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    redirect(dashboard_path($_SESSION['role']));
}
redirect('login.php');
