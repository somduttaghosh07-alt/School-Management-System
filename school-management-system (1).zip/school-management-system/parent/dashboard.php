<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['parent']);
$db = getDB();

$stmt = $db->prepare('SELECT * FROM parents WHERE user_id = ?');
$stmt->execute([$_SESSION['user_id']]);
$parent = $stmt->fetch();
if (!$parent) {
    flash('danger', 'Parent profile not found. Contact the administrator.');
    redirect('logout.php');
}

$stmt = $db->prepare(
    'SELECT s.*, c.name AS class_name, sec.name AS section_name
     FROM students s JOIN classes c ON c.id = s.class_id LEFT JOIN sections sec ON sec.id = s.section_id
     WHERE s.parent_id = ? ORDER BY s.name'
);
$stmt->execute([$parent['id']]);
$children = $stmt->fetchAll();
$notices = notices_for($db, 'parent', 5);

$pageTitle = 'Parent Dashboard';
include __DIR__ . '/../includes/header.php';
?>
<h5 class="mb-3">My children</h5>
<div class="row g-3 mb-3">
  <?php if (!$children): ?>
    <div class="col-12"><div class="card"><div class="card-body empty-state">No children are linked to your account yet. Please contact the school office.</div></div></div>
  <?php endif; ?>
  <?php foreach ($children as $c):
      $att    = attendance_summary($db, (int)$c['id']);
      $fees   = fee_summary($db, (int)$c['id']);
      $result = latest_result($db, (int)$c['id']);
  ?>
    <div class="col-lg-6">
      <div class="card h-100">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3 mb-3">
            <span class="avatar" style="width:52px;height:52px;font-size:1.3rem"><?= e(strtoupper(substr($c['name'], 0, 1))) ?></span>
            <div>
              <h6 class="mb-0"><?= e($c['name']) ?></h6>
              <small class="text-muted"><?= e($c['class_name']) ?><?= $c['section_name'] ? ' - ' . e($c['section_name']) : '' ?> &middot; <?= e($c['admission_no']) ?></small>
            </div>
          </div>
          <div class="row text-center g-2">
            <div class="col-4"><div class="p-2 rounded bg-light">
              <div class="fw-bold fs-5"><?= $att['percent'] ?>%</div><small class="text-muted">Attendance</small></div></div>
            <div class="col-4"><div class="p-2 rounded bg-light">
              <div class="fw-bold fs-5"><?= $result ? e($result['percent']) . '%' : '-' ?></div>
              <small class="text-muted"><?= $result ? e($result['name']) : 'No result yet' ?></small></div></div>
            <div class="col-4"><div class="p-2 rounded bg-light">
              <div class="fw-bold fs-5 <?= $fees['pending'] > 0 ? 'text-danger' : 'text-success' ?>"><?= e(money($fees['pending'])) ?></div>
              <small class="text-muted">Fees pending</small></div></div>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="card-header">School announcements</div>
  <div class="card-body">
    <?php if (!$notices): ?><div class="empty-state">No announcements.</div><?php endif; ?>
    <?php foreach ($notices as $n): ?>
      <div class="notice-item">
        <strong><?= e($n['title']) ?></strong>
        <p class="mb-1 text-muted small"><?= e($n['body']) ?></p>
        <small class="text-muted"><?= e(date('d M Y', strtotime($n['notice_date']))) ?></small>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
