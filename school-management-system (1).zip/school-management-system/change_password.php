<?php
require_once __DIR__ . '/includes/auth.php';
require_login();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!verify_csrf()) {
        $errors[] = 'Your session expired. Please try again.';
    } else {
        $db = getDB();
        $stmt = $db->prepare('SELECT password_hash FROM users WHERE id = ?');
        $stmt->execute([$_SESSION['user_id']]);
        $hash = $stmt->fetchColumn();

        if (!$hash || !password_verify($current, $hash)) {
            $errors[] = 'Current password is incorrect.';
        }
        if (strlen($new) < 8 || !preg_match('/[A-Za-z]/', $new) || !preg_match('/\d/', $new)) {
            $errors[] = 'New password must be at least 8 characters and contain letters and numbers.';
        }
        if ($new !== $confirm) {
            $errors[] = 'New password and confirmation do not match.';
        }
        if ($current !== '' && $current === $new) {
            $errors[] = 'New password must be different from the current password.';
        }

        if (!$errors) {
            $db->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
               ->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user_id']]);
            log_activity('Changed account password');
            flash('success', 'Password changed successfully.');
            redirect('change_password.php');
        }
    }
}

$pageTitle = 'Change Password';
include __DIR__ . '/includes/header.php';
?>
<div class="row justify-content-center">
  <div class="col-lg-6 col-xl-5">
    <div class="card">
      <div class="card-header"><i class="bi bi-key me-2"></i>Change your password</div>
      <div class="card-body p-4">
        <?php foreach ($errors as $err): ?>
          <div class="alert alert-danger py-2"><?= e($err) ?></div>
        <?php endforeach; ?>
        <form method="post" novalidate>
          <?= csrf_field() ?>
          <div class="mb-3">
            <label class="form-label" for="current_password">Current password</label>
            <input type="password" class="form-control" id="current_password" name="current_password" autocomplete="current-password" required>
          </div>
          <div class="mb-3">
            <label class="form-label" for="new_password">New password</label>
            <input type="password" class="form-control" id="new_password" name="new_password" autocomplete="new-password" minlength="8" required>
            <div class="form-text">Minimum 8 characters, with letters and numbers.</div>
          </div>
          <div class="mb-4">
            <label class="form-label" for="confirm_password">Confirm new password</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" autocomplete="new-password" required>
          </div>
          <button class="btn btn-primary px-4" type="submit">Update password</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
